// Importar los módulos
const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
const MongoClient = require("mongodb").MongoClient;

const mongoURL = "mongodb://localhost:27017";

const app = express();
const server = http.createServer(app);

const io = socketIO(server);

MongoClient.connect(mongoURL, (err, client) => {
  if (err) {
    console.error("Error de conexión a MongoDB:", err);
    return;
  }

  console.log("Conexión exitosa a MongoDB");

  const db = client.db("testdb");
  const messagesCollection = db.collection("messages");

  io.on("connection", (socket) => {
    console.log("Nuevo cliente conectado");

    socket.on("message", (data) => {
      console.log("Mensaje recibido:", data);

      messagesCollection.insertOne(data, (err, result) => {
        if (err) {
          console.error("Error al insertar mensaje en la base de datos:", err);
          return;
        }

        console.log("Mensaje registrado en la base de datos");

        // Emitir el mensaje a todos los clientes conectados
        io.emit("message", data);
      });
    });
  });

  const port = 3000;
  server.listen(port, () => {
    console.log(`Servidor Socket.io escuchando en el puerto ${port}`);
  });
});
